public class OrdenacaoMergeSort<T extends Comparable<T>> extends OrdenacaoAbstract<T> {

    @Override
    public void ordenar() {

    }

    public void merge(int inicio, int fim, int meio) {
        
    }
}
